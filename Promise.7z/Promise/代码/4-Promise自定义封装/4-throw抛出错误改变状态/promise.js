//声明构造函数
console.log(1234);
function Promise(executor){
    //添加属性
    this.PromiseState = 'pending';
    this.PromiseResult = null;
    //保存实例对象的 this 的值
    const self = this;// self _this that
    //resolve 函数
    function resolve(data){
        if (self.PromiseState === 'pending') {  // 只有状态为pending时才可以修改为别的状态
            //1. 修改对象的状态 (promiseState)
            self.PromiseState = 'fulfilled';// resolved
            //2. 设置对象结果值 (promiseResult)
            self.PromiseResult = data;
        }
        
    }
    //reject 函数
    function reject(data){
        if (self.PromiseState === 'pending') {  // 只有状态为pending时才可以修改为别的状态
            //1. 修改对象的状态 (promiseState)
            self.PromiseState = 'rejected';// 
            //2. 设置对象结果值 (promiseResult)
            self.PromiseResult = data;
        }
    }
    try{
        //同步调用『执行器函数』  try里面出错会走catch  直接调用catch
        executor(resolve, reject);  
    }catch(e){  
        //修改 promise 对象状态为『失败』
        reject(e);    
    }
}
/**
 * then方法里面会传两个回调函数，一个为成功的回调，一个为失败的回调
 * 在执行两个回调时，要判断是否是对应自己的状态
 * 成功的回调：
 *     作用---调用的是Promise里面的resolve方法   修改状态   传递数据  
 *      怎么调用： new Promise().resolve() 吗?  繁琐 
 *       那如果把方法存到数组，通过数组来调用呢 
 *          假如是数组：    
 * 失败的回调：
 *     作用---调用的是Promise里面的reject方法   修改状态   传递数据   
 */
//添加 then 方法
Promise.prototype.then = function(onResolved, onRejected){
    if(this.PromiseState === 'fulfilled') {
        onResolved()
        console.log(`onResolved`)
    }
    if(this.PromiseState === 'rejected') {
        onRejected()
        console.log(`rejected`)
    }

    if(this.PromiseState === 'pending') {
        this.callback = {
            onResolved,
            onRejected
        }
    }
}



/**
 * 使用Promise时  可以使用下面的方式：
 * 
 * 方法一：
 * return new Promise((resolve, reject) => {
 * 
 *  成功或失败的回调
 * })
 * 
 * 方法二：
 * 
 * let p = new Promise()
 * p.then(
 *   (resolve) => {
 *    成功时执行   应该调用Promise里面的resolve方法
 *   },
 *   (reject) => {
 *    失败时执行  应该调用Promise里面的reject方法
 *   }
 * )
 * 
 * 
 * 实例对象 通过then时可以调用状态对应的方法，
 * 
 * 现在是要把  then回调函数里面的方法与构造函数中的方法  关联起来？   如何关联？
 * 
 * 把两个方法添加到对象里面。然后将对象绑定在this上， 就可以在Promise的任何地方进行调用了
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 在原型上可以拿到 绑定在构造函数上的属性或方法：
 */