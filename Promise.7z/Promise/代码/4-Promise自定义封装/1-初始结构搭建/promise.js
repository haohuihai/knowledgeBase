
function Promise(executor){

}

//添加 then 方法
Promise.prototype.then = function(onResolved, onRejected){

}