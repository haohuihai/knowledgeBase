/**
 * 先红灯 三秒 亮一次 
 * 后绿灯 一秒 亮一次
 * 再黄灯 两秒 亮一次
 * 
 * 
 * 
 * 
 */
//  function red(){
//     console.log('red');
// }
// function green(){
//     console.log('green');
// }
// function yellow(){
//     console.log('yellow');
// }

//  var light = function(timmer, cb){
//     return new Promise(function(resolve, reject) {
//         setTimeout(function() {
//             cb();
//             resolve();
//         }, timmer);
//     });
// };

// var step = function() {
//     Promise.resolve().then(function(){
//         return light(3000, red);
//     }).then(function(){
//         return light(2000, green);
//     }).then(function(){
//         return light(1000, yellow);
//     }).then(function(){
//         step();
//     });
// }

// step();

const s = new Date().getSeconds();

setTimeout(function() {
  // 输出 "2"，表示回调函数并没有在 500 毫秒之后立即执行
  console.log("Ran after " + (new Date().getSeconds() - s) + " seconds");
}, 500);

while(true) {
  if(new Date().getSeconds() - s >= 2) {
    console.log("Good, looped for 2 seconds");
    break;
  }
}