let a = {
    for: function (a,b) {
        a
    }
}